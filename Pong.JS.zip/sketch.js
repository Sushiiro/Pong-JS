//varáveis da Bolinha
let xBolinha = 300;
let yBolinha = 200;
let diametro = 13;
let raio = diametro / 2 ;

//velocidade da Bolinha
let velocidadexBolinha = 6;
let velocidadeyBolinha = 6;
let RaqueteComprimento = 10;
let Raquetealtura = 90;

//variaveis da raquete
let xRaquete = 5;
let yRaquete = 150;

//Variáveis do Inimigo
let xRaqueteOponente = 585;
let yRaqueteOponente = 150;
let velocidadeYoponente;

let colidiu = false;

//placar do jogo
let meusPontos = 0;
let pontosOponente = 0;

//Sons do Jogo
let raquetada;
let ponto;
let trilha

//erro oponente
let chanceDeErrar = 0;

function preload(){
  trilha = loadSound("hoje-vai-ter-festinha.mp3");
  ponto = loadSound("cavalo.mp3")
  raquetada = loadSound ("discord-sounds.mp3")
  
}

function setup() {
  createCanvas(600, 400);
  trilha.loop();
}

function draw() {
  background(0);
  mostraBolinha();
  movimentaBolinha();
  verificaColisaoBorda();
  mostraRaquete(xRaquete,yRaquete);
  movimentaminhaRaquete();
  //verificaColisaoRaquete();
  verificacolisaoRaquete(xRaquete, yRaquete);         
  mostraRaquete(xRaqueteOponente,yRaqueteOponente);
  movimentaRaqueteOponente();
  verificacolisaoRaquete(xRaqueteOponente, yRaqueteOponente)
  incluirPlacar();
  marcaponto();
  calculaChanceDeErrar();
  bolinhaNaoFicaPresa();
}
 
function mostraBolinha(){
  circle(xBolinha,yBolinha,diametro); 
} 

function movimentaBolinha(){
  xBolinha += velocidadexBolinha;
  yBolinha += velocidadeyBolinha;
}

function verificaColisaoBorda(){
 if (xBolinha + raio > width ||
    xBolinha - raio < 0){
    velocidadexBolinha *= -1;
  }
 if (yBolinha + raio > height ||
    yBolinha - raio < 0){
    velocidadeyBolinha *= -1;
 }
}

function mostraRaquete(x,y){
  rect(x,y,RaqueteComprimento,Raquetealtura);
}

function movimentaminhaRaquete(){
  if (keyIsDown(UP_ARROW)){
    yRaquete -= 10;
  }
   if (keyIsDown(DOWN_ARROW)){
    yRaquete += 10;
   }
}

function verificaColisaoRaquete(){
  if (xBolinha - raio < xRaquete + RaqueteComprimento && yBolinha - raio < yRaquete + Raquetealtura &&
     yBolinha + raio > yRaquete){ 
    velocidadexBolinha *= -1;  
    raquetada.play();
  }
}

function verificacolisaoRaquete(x,y){
  colidiu = collideRectCircle(x,y,RaqueteComprimento,Raquetealtura,xBolinha,yBolinha,raio);
  if (colidiu){
    velocidadexBolinha *= -1;
    raquetada.play();
  }
}

function movimentaRaqueteOponente(){
    //if (keyIsDown(87)){
    //yRaqueteOponente -= 10;
  //}
   //if (keyIsDown(83)){
    //yRaqueteOponente += 10;
   //}
  
  velocidadeYoponente = yBolinha - yRaqueteOponente - RaqueteComprimento /2 - 30;
  yRaqueteOponente += velocidadeYoponente + chanceDeErrar
 }


function incluirPlacar(){
  stroke(255);
  textAlign(CENTER);
  textSize(16);
  fill(color(255, 140, 0));
  rect(150, 10, 40, 20);
  fill(255);
  text(meusPontos, 170, 26);
  fill(color(255, 140, 0));
  rect(450, 10, 40, 20);
  fill(255);
  text(pontosOponente, 470, 26)
}
function marcaponto(){
  if (xBolinha > 590){
    meusPontos += 1;
    ponto.play();
  }
  if (xBolinha < 10){
    pontosOponente += 1;
    ponto.play();
  }
 }

function calculaChanceDeErrar() {
  if (pontosOponente >= meusPontos) {
    chanceDeErrar += 1
    if (chanceDeErrar >= 39){
    chanceDeErrar = 40
    }
  } else {
    chanceDeErrar -= 1
    if (chanceDeErrar <= 35){
    chanceDeErrar = 35
    }
  }
}
function bolinhaNaoFicaPresa(){
  if (xBolinha + raio < 0){
  xBolinha = 23;
    if (xBolinha > 600);
 }
}